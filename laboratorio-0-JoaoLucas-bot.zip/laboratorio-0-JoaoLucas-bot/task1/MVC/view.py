import controller
 
def main():
    
    while True: 
    # O "While True" serve para fazer o programa "correr" de forma contínua.
    
        try:
        # Usei o "try" pela questão do erro "EOFError".
        
            opcao = input()
            valores = opcao.split(" ") 
            # A opção recebe os input's do utilizador e a variável "valores" recebe as várias variáveis "opcao", dividas por espaços.
            
            if (len(valores) < 3) and ((valores[0]) != "F"): 
                print("Não é possível realizar a operação.") 
            # Começei por verificar os dois tipos de possível "erro". Se não tivermos nenhum erro, seguimos para as operações.
            
            else:
                if valores[0]=="S":
                    resultado= controller.soma(int(valores[1]),int(valores[2])) 
                    # Verifico o índice "0" da variável "valores" e invoco a operação da função "soma" (que consta no controller).
                    print(f"O resultado ́e {resultado}.")
                    
                elif valores[0]=="SU":
                    if int(valores[1])<int(valores[2]): 
                    # Na Subtração temos uma especial condição de erro, em que o 1º valor numérico não pode ser menor que o 2º valor numérico.
                        print("Não é possível realizar a operação.") 
                        # Desse modo, inseri esta condição, bem como o seu output.
                    else:
                        resultado= controller.subtraçao(int(valores[1]),int(valores[2])) 
                        # Verifico o índice "0" da variável "valores" e invoco a operação da função "subtraçao" (que consta no controller).
                        print(f"O resultado ́e {resultado}.")
                    
                elif valores[0]=="M":
                    resultado= controller.multiplicaçao(int(valores[1]),int(valores[2])) 
                    # Verifico o índice "0" da variável "valores" e invoco a operação da função "multiplicaçao" (que consta no controller).
                    print(f"O resultado ́e {resultado}.")
                
                elif valores[0]=="D":
                    resultado= controller.divisao(int(valores[1]),int(valores[2])) 
                    # Verifico o índice "0" da variável "valores" e invoco a operação da função "divisao" (que consta no controller).
                    print(f"O resultado ́e {resultado}.")
                    
                elif valores[0]=="F":
                    numero= controller.fatorizaçao(int(valores[1])) 
                    # Verifico o índice "0" da variável "valores" e invoco o "fatorial" da função "fatorizaçao" (que consta no controller).
                    print(f"O resultado é {numero}.")
            
        except EOFError as e: 
            print(end="")
            # Usei o "except" pela questão do erro "EOFError".