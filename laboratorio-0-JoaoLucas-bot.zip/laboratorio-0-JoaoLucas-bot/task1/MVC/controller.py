import model
 
from math import factorial
# Importei a biblioteca para poder calcular o fatorial.
 
def soma(a,b):
 return a + b
 # Nesta função é feita a operação de soma dos valores.
 
def subtraçao(a,b):
 return a - b
 # Nesta função é feita a operação de subtração dos valores.
 
def multiplicaçao(a,b):
 return a * b
 # Nesta função é feita a operação de multiplicação dos valores.
 
def divisao(a,b):
 return a / b
 # Nesta função é feita a operação de divisão dos valores
 
def fatorizaçao(a):
 return factorial(a)
 # Utilizando a biblioteca e a função "factorial", é encontrado o factorial do número inserido em "valores[0]".