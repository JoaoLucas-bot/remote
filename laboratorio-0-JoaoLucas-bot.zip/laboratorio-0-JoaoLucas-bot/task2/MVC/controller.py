import model

def construçao_matrix(numero_linhas_colunas, valores):
    # Vamos usar a função "contruçao_matriz" para organizar a nossa matriz,
     
     matrix = []
     n = 0

     for i in range(numero_linhas_colunas):
          linha = []
          for j in range(numero_linhas_colunas):
               linha.append(int(valores[n]))
               n+=1
          matrix.append(linha)
     return matrix

def soma_linhas(matrix):
     for i in range (len(matrix)):
          if( i == 0 ):
               soma_linha_zero = sum(matrix[0])
          elif(soma_linha_zero != sum(matrix[i])):
               soma_linha_zero = -1
               return soma_linha_zero
     return soma_linha_zero   

def soma_colunas(matrix):
     soma_coluna_zero = 0
     soma_coluna_diferente_zero = 0
     for i in range (len(matrix)):
          soma_coluna_diferente_zero = 0
          for j in range (len(matrix)):
               if(i == 0):
                    soma_coluna_zero += matrix[j][i]
               else:
                    soma_coluna_diferente_zero += matrix[j][i]
          if(i != 0 and soma_coluna_zero != soma_coluna_diferente_zero):
               soma_coluna_zero = -1
     return soma_coluna_zero

def soma_diagonal(matrix):
     soma_diagonal = 0
     for i in range(len(matrix)):
          soma_diagonal += matrix[i][i]
     return soma_diagonal