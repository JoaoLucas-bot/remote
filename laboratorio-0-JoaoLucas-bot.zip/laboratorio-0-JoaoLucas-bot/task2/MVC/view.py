import controller

def main():
	
    while True:
	# O "While True" serve para fazer o programa "correr" de forma contínua.
        try:
			# Usei o "try" pela questão do erro "EOFError".

            user = input("").split(" ")
			# Recebi o input do utilizador e dividi-o logo em índices, pelos " ".

            if (user[1] != user[2]):
                print("Matriz inválida.")
			# Tendo em conta que a matriz tem que ser quadrada, vericamos se o nº de Linhas é igual ao nº de Colunas

            else:
                n_Matrix = controller.construçao_matrix (int(user[1]), user[3:])
                linha = controller.soma_linhas (n_Matrix)
                coluna = controller.soma_colunas (n_Matrix)
                diagonal = controller.soma_diagonal (n_Matrix)

                
                if (linha > 0 and coluna > 0 and (linha == coluna == diagonal)):
                    print ("É um quadrado mágico.")
					# Na linha 23, o programa compara se todas combinações são iguais "(linha == coluna == diagonal)". 
					# Caso o valor seja o mesmo para as 3 variáveis, então o quadrado é mágico.
                else:
                    print("Não é um quadrado mágico.")
					# Caso as variáveis comparadas não sejam iguais, o quadrado não é mágico. 

        except EOFError:
            return
			# Usei o "except" pela questão do erro "EOFError".